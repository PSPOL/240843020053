import React from 'react'

export default function GroomerSidebar() {
  return (
    <div>GroomerSidebar</div>
  )
}
