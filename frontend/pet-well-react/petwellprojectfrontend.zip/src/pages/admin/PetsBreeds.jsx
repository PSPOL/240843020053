import React from 'react'

export default function PetsBreeds() {
  return (
    <div>PetsBreeds</div>
  )
}
