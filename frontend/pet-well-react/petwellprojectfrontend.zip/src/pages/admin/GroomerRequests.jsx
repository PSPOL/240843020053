import React from 'react'

export default function GroomerRequests() {
  return (
    <div>GroomerRequests</div>
  )
}
