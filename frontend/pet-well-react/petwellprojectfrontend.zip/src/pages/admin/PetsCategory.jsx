import React from 'react'

export default function PetsCategory() {
  return (
    <div>PetsCategory</div>
  )
}
