import React from 'react'

export default function VeterinaryRequest() {
  return (
    <div>VeterinaryRequest</div>
  )
}
