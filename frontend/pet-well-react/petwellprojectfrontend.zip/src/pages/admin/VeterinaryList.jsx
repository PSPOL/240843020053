import React from 'react'

export default function VeterinaryList() {
  return (
    <div>VeterinaryList</div>
  )
}
