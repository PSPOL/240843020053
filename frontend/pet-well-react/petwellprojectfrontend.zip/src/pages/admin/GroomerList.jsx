import React from 'react'

export default function GroomerList() {
  return (
    <div>GroomerList</div>
  )
}
