import React from 'react'

export default function SitterSidebar() {
  return (
    <div>SitterSidebar</div>
  )
}
