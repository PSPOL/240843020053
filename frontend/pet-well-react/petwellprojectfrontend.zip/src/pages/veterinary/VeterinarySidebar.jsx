import React from 'react'

export default function VeterinarySidebar() {
  return (
    <div>VeterinarySidebar</div>
  )
}
